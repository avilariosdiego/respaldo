<?php
  include_once('conexion/cnx.php');  //Agregando la Conexión a Base de Datos
  include_once('sesion.php');        //Agregando la Verificación de Sesión
  ?>
  <!DOCTYPE html>
  <html lang="es">
  <head>
    <!--Metadatos y Datos-->
    <title>KTS Corp - Empleado</title>
    <meta charset="utf-8">
    <meta name="KTS Corp" content="Extranet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="../img/icono.png">

    <!--Local-->
    <link rel="stylesheet" type="text/css" href="../css/estilos.css">
    <link rel="stylesheet" type="text/css" href="../css/sidebar.css">

    <!--Bootstrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <!--Iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  </head>
  <body>

    <!-- Load Facebook SDK for JavaScript -->
    <div id="fb-root"></div>
    <script>
      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v3.3'
        });
      };

      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/es_LA/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

      <!-- Your customer chat code -->
      <div class="fb-customerchat"
      attribution=setup_tool
      page_id="207937452626406"
      theme_color="#395784"
      logged_in_greeting="¡Hola! En que puedo ayudarte?"
      logged_out_greeting="¡Hola! En que puedo ayudarte?">
    </div>

    <!--Menú-->
    <?php
    include_once('menuuser.php');
    ?>

    <div id="content-wrapper">
      <div class="container text-center">
        <h3 class="text-center text-dark titulos box">USUARIO</h3>
        <hr><br>
        
        <div class="row">
          <div class="col-lg-6">
            <a href="cartas.php"><i class="fas fa-file-alt box" style="font-size: 100px; color: #395784;"></i></a>
            <br>
            <h3 class="text-center">Cartas de Trabajo</h3>
            <hr style="background-color: #848584">
            <p>Cualquier usuario ya sea administrador o empleado, podrán solicitar cartas de trabajo mediante un pequeño formulario del mismo, el cuál <strong>debe ser entregado y procesado por el personal de talento humano de la empresa.</strong></p>
          </div>
          <div class="col-lg-6">
            <a href="formatos.php"><i class="fas fa-file-pdf box" style="font-size: 100px; color: #395784;"></i></a>
            <br>
            <h3 class="text-center">Formatos</h3>
            <hr style="background-color: #848584">
            <p>Esta sección contiene todos lo formatos de la empresa, los cuales son: <strong>Directorio de Contactos, solicitud de vacaciones, permisos, requisición de personal y solicitud de anticipos de prestaciones sociales.</strong></p>     
          </div>
          <div class="col-lg-6">
            <a href="politicas.php"><i class="fas fa-book box" style="font-size: 100px; color: #395784;"></i></a>
            <br>
            <h3 class="text-center">Políticas</h3>
            <hr style="background-color: #848584">
            <p>Esta sección contiene las <strong>políticas de recomendación, políticas de vacaciones, políticas de prestaciones sociales y las políticas del uso del sistema biométrico</strong> dirigida a todo el personal de KTS Corp.</p>
          </div>
          <div class="col-lg-6">
            <?php
            $querybuscarC = "SELECT * FROM usuarios";
            $QB = mysqli_query($cnx, $querybuscarC) or die(mysqli_error($cnx));
            if (mysqli_num_rows($QB) > 0 )
            {
              ?>
              <?php
              $nro = 0;
              while( $fila=mysqli_fetch_array($QB) )
              {
                $nro++;
                $idusuario = $fila['idusuario'];
                $nombre = utf8_decode($fila['nombre']);
                $apellido = utf8_decode($fila['apellido']);
                $cedula = $fila['cedula'];
                $idcargo = $fila['idcargo'];
                $idempresa = $fila['idempresa'];
                
                $cnx->set_charset("utf8");
                $querybuscarOP = " SELECT * FROM usuarios_cargo WHERE idcargo = '$idcargo' ";
                $QO = mysqli_query($cnx, $querybuscarOP) or die(mysqli_error($cnx));
                while (($fila=mysqli_fetch_array($QO)))
                {
                  $descripcargo= $fila['descripcargo'];
                }
                
                $querybuscarEM = " SELECT * FROM usuarios_empresa WHERE idempresa = '$idempresa' ";
                $QEM = mysqli_query($cnx, $querybuscarEM) or die(mysqli_error($cnx));
                while (($fila=mysqli_fetch_array($QEM)))
                {
                 $descripempresa= $fila['descripempresa'];
               }
               ?>
               <?php
             }
             ?>
             <?php
        }else{
          ?>
          <?php
        }
        ?>
             <a href="modificarclave.php?id=<?php echo $idusuario ?>"><i class="fas fa-user-edit box" style="font-size: 100px; color: #395784;"></i></a>
             <br>
             <h3 class="text-center">Modificar Datos</h3>
             <hr style="background-color: #848584">
             <p>Cambia o actualiza tus datos! <strong>Por medios de seguridad debes actualizar tu contraseña cada cierto tiempo, en el peor de los casos un administrador debió generarte una contraseña genérica, actualízala lo más pronto posible.</p>
             </div>
           </div>
           <footer class="sticky-footer">
            <div class="container my-auto">
              <div class="copyright text-center my-auto">
                © <span id="output"></span> | KTS Corp - Todos los derechos reservados | RIF J-29454989-6
              </div>
            </div>
          </footer>
        </div>
      </div>

      <!--JS-->
      <script src="../js/funciones.js"></script>
      <script src="../js/sidebar.js"></script>

    </body>
    </html>