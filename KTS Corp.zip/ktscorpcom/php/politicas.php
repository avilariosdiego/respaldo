<?php
  include_once('conexion/cnx.php');  //Agregando la Conexión a Base de Datos
  include_once('sesion.php');        //Agregando la Verificación de Sesión
  ?>
  <!DOCTYPE html>
  <html lang="es">
  <head>
    <!--Metadatos y Datos-->
    <title>KTS Corp - Políticas</title>
    <meta charset="utf-8">
    <meta name="KTS Corp" content="Extranet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="../img/icono.png">

    <!--Local-->
    <link rel="stylesheet" type="text/css" href="../css/estilos.css">
    <link rel="stylesheet" type="text/css" href="../css/sidebar.css">

    <!--Bootstrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <!--Iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  </head>
  <body>

    <!-- Load Facebook SDK for JavaScript -->
    <div id="fb-root"></div>
    <script>
      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v3.3'
        });
      };

      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/es_LA/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

      <!-- Your customer chat code -->
      <div class="fb-customerchat"
      attribution=setup_tool
      page_id="207937452626406"
      theme_color="#395784"
      logged_in_greeting="¡Hola! Tienes alguna duda sobre nuestras políticas?"
      logged_out_greeting="¡Hola! Tienes alguna duda sobre nuestras políticas?">
    </div>

    <!--Menú-->
    <?php
    if($_SESSION['opc_user'] == 'usuarios_admin'){
      include_once('menuadmin.php');
    }elseif($_SESSION['opc_user'] == 'usuarios'){
      include_once('menuuser.php');
    }
    ?>

    <div id="content-wrapper">
      <div class="container text-center">
        <br>
        <div class="row text-center">
          <div class="col-sm-4">
            <hr>
          </div>
          <div class="col-sm-4">
            <h3 class="text-center text-dark box">POLÍTICAS</h3>
          </div>
          <div class="col-sm-4">
            <hr>
          </div>
        </div>
        <br>
        <div class="row">
          <div class="col-lg-6"><br>
            <i class="fas fa-handshake box" style="font-size: 100px; color: #395784;"></i>
            <br>
            <h3 class="text-center">Políticas de Prestaciones</h3>
            <hr style="background-color: #848584">
            <p>En esta sección se encuentran las políticas de prestaciones, en el cuál se conoce su <strong>propósito y alcance, definiciones, documentos asociados, responsables directos del cumpliminento de este procedimiento, políticas de prestaciones sociales y su procedimiento.</strong></p>
            <a href="../legal/politicas_de_prestaciones.html" target="_blank"><button type="button" class="btn btn-kts" style="font-size: 18px;">Saber Más</button></a>
          </div>
          <div class="col-lg-6"><br>
            <i class="far fa-hand-paper box" style="font-size: 100px; color: #395784;"></i>
            <br>
            <h3 class="text-center">Políticas de Sistema Biométrico</h3>
            <hr style="background-color: #848584">
            <p>En esta sección se encuentran las políticas del uso del sistema biométrico, en el cuál se conoce su <strong>propósito y alcance, definiciones, documentos asociados, responsables directos del cumplimiento de este procedimiento, política y su procedimiento.</strong></p>
            <a href="../legal/politicas_de_biometrico.html" target="_blank"><button type="button" class="btn btn-kts" style="font-size: 18px;">Saber Más</button></a>
          </div>
        </div>

        <br>

        <div class="row slideanim">
          <div class="col-lg-6"><br>
            <i class="fas fa-plane box" style="font-size: 100px; color: #395784;"></i>
            <br>
            <h3 class="text-center">Políticas de Vacaciones</h3>
            <hr style="background-color: #848584">
            <p>En esta sección se encuentran las políticas de vacaciones, en el cuál se conoce su <strong>propósito y alcance, definiciones, documentos asociados, responsables directos del cumpliminento de este procedimiento, políticas de vacaciones, bono vacacional, disfrute fraccionado de vacaciones y su procedimiento.</strong></p>
            <a href="../legal/politicas_de_vacaciones.html" target="_blank"><button type="button" class="btn btn-kts" style="font-size: 18px;">Saber Más</button></a>
          </div>
          <div class="col-lg-6"><br>
            <i class="fas fa-male box" style="font-size: 100px; color: #395784;"></i>
            <br>
            <h3 class="text-center">Políticas de Recomendación</h3>
            <hr style="background-color: #848584">
            <p>En esta sección se encuentran las políticas de recomendación, en el cuál se conoce su <strong>propósito y alcance, definiciones, documentos asociados, responsables directos del cumpliminento de este procedimiento y su procedimiento.</strong></p>
            <a href="../legal/politicas_de_recomendacion.html" target="_blank"><button type="button" class="btn btn-kts" style="font-size: 18px;">Saber Más</button></a>    
          </div>
        </div>
        <br>
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              © <span id="output"></span> | KTS Corp - Todos los derechos reservados | RIF J-29454989-6
            </div>
          </div>
        </footer>
      </div>
    </div>

    <!--JS-->
    <script src="../js/funciones.js"></script>
    <script src="../js/sidebar.js"></script>

  </body>
  </html>