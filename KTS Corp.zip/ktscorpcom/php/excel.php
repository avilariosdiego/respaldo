<?php
  include_once('conexion/cnx.php');  //Agregando la Conexión a Base de Datos
  include_once('sesion.php');        //Agregando la Verificación de Sesión
  ?>
  <!DOCTYPE html>
  <html lang="es">
  <head>
  	<!--Metadatos y Datos-->
  	<title>KTS Corp - Descargar Excel</title>
  	<meta charset="utf-8">
  	<meta name="KTS Corp" content="Extranet">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="icon" type="image/x-icon" href="../img/icono.png">

  	<!--Bootstrap-->
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

  	<!--Iconos-->
  	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  </head>
  <body>

  	<?php
  	header('Content-type: application/vnd.ms-excel;charset=iso-8859-15');
  	header('Content-Disposition: attachment; filename=usuarios_kts.xls');
  	?>

  	<?php
  	$querybuscarC = "SELECT * FROM usuarios_admin";
  	$QB = mysqli_query($cnx, $querybuscarC) or die(mysqli_error($cnx));
  	if (mysqli_num_rows($QB) > 0 )
  	{
  		?>
  		<div class="container table-responsive">
  			<table class="table table-hover table-bordered" id="datos">
  				<thead>
  					<tr>
              <th><strong>N°</strong></th>
  						<th><strong>Nombre</strong></th>
  						<th><strong>Apellido</strong></th>
  						<th><strong>Cédula</strong></th>
  						<th><strong>Cargo</strong></th>
  						<th><strong>Compañia</strong></th>
  					</tr>
  				</thead>
  				<?php
  				$nro = 0;
  				while( $fila=mysqli_fetch_array($QB) )
  				{
  					$nro++;
  					$idadmin = $fila['idadmin'];
  					$nombre = $fila['nombre'];
  					$apellido = $fila['apellido'];
  					$cedula = $fila['cedula'];
  					$idcargo = $fila['idcargo'];
  					$idempresa = $fila['idempresa'];

  					$cnx->set_charset("utf8");
  					$querybuscarOP = " SELECT * FROM usuarios_cargo WHERE idcargo = '$idcargo' ";
  					$QO = mysqli_query($cnx, $querybuscarOP) or die(mysqli_error($cnx));
  					while (($fila=mysqli_fetch_array($QO)))
  					{
  						$descripcargo= $fila['descripcargo'];
  					}

  					$querybuscarEM = " SELECT * FROM usuarios_empresa WHERE idempresa = '$idempresa' ";
  					$QEM = mysqli_query($cnx, $querybuscarEM) or die(mysqli_error($cnx));
  					while (($fila=mysqli_fetch_array($QEM)))
  					{
  						$descripempresa= $fila['descripempresa'];
  					}
  					?>
  					<tbody id="datos">
  						<tr>
                <td><?php echo $nro ?></td>
  							<td><?php echo $nombre ?></td>
  							<td><?php echo $apellido ?></td>
  							<td><?php echo $cedula ?></td>
  							<td><?php echo $descripcargo ?></td>
  							<td><?php echo $descripempresa ?></td>
  						</tr>
  					</tbody>
  					<?php
  				}
  				?>
  			</table>
  			<?php
  		}
  		?>
  	</div>
  </div>

  <hr>

  <?php
  $querybuscarC = "SELECT * FROM usuarios";
  $QB = mysqli_query($cnx, $querybuscarC) or die(mysqli_error($cnx));
  if (mysqli_num_rows($QB) > 0 )
  {
  	?>
  	<div class="container table-responsive">
  		<table class="table table-hover table-bordered" id="datos2">
  			<thead>
  				<tr>
            <th><strong>N°</strong></th>
  					<td><strong>Nombre</strong></td>
  					<td><strong>Apellido</strong></td>
  					<td><strong>Cédula</strong></td>
  					<td><strong>Cargo</strong></td>
  					<td><strong>Compañia</strong></td>
  				</tr>
  			</thead>
  			<?php
  			$nro = 0;
  			while( $fila=mysqli_fetch_array($QB) )
  			{
  				$nro++;
  				$idusuario = $fila['idusuario'];
  				$nombre = utf8_decode($fila['nombre']);
  				$apellido = utf8_decode($fila['apellido']);
  				$cedula = $fila['cedula'];
  				$idcargo = $fila['idcargo'];
  				$idempresa = $fila['idempresa'];

  				$cnx->set_charset("utf8");
  				$querybuscarOP = " SELECT * FROM usuarios_cargo WHERE idcargo = '$idcargo' ";
  				$QO = mysqli_query($cnx, $querybuscarOP) or die(mysqli_error($cnx));
  				while (($fila=mysqli_fetch_array($QO)))
  				{
  					$descripcargo= $fila['descripcargo'];
  				}

  				$querybuscarEM = " SELECT * FROM usuarios_empresa WHERE idempresa = '$idempresa' ";
  				$QEM = mysqli_query($cnx, $querybuscarEM) or die(mysqli_error($cnx));
  				while (($fila=mysqli_fetch_array($QEM)))
  				{
  					$descripempresa= $fila['descripempresa'];
  				}
  				?>
  				<tbody id="datos">
  					<tr>
              <td><?php echo $nro ?></td>
  						<td><?php echo $nombre ?></td>
  						<td><?php echo $apellido ?></td>
  						<td><?php echo $cedula ?></td>
  						<td><?php echo $descripcargo ?></td>
  						<td><?php echo $descripempresa ?></td>
  					</tr>
  				</tbody>
  				<?php
  			}
  			?>
  		</table>
  		<?php
  	}else{
  		?>
  		<h4>POR LOS MOMENTOS NO HAY NINGÚN USUARIO DE EMPLEADO</h4>
  		<?php
  	}
  	?>
  </div>
</div>
</div>
</div>

<!--JS-->
<script src="../js/funciones.js"></script>
<script src="../js/sidebar.js"></script>
<script>
	function preguntaradmin(idadmin){
		if(confirm('¿Está seguro que desea eliminar el usuario seleccionado?'))
		{
			window.location.href = "eliminaradmin.php?id="+idadmin; 
		}
	}

	function preguntaruser(idusuario){
		if(confirm('¿Está seguro que desea eliminar el usuario seleccionado?'))
		{
			window.location.href = "eliminaruser.php?id="+idusuario; 
		}
	}
</script>

<!--Buscar Administrador-->
<script>
	function doSearch() {
		var tableReg = document.getElementById('datos');
		var searchText = document.getElementById('searchTerm').value.toLowerCase();
		var cellsOfRow = "";
		var found = false;
		var compareWith = "";

  //Recorremos todas las filas con contenido de la tabla
  for (var i = 1; i < tableReg.rows.length; i++) {
  	cellsOfRow = tableReg.rows[i].getElementsByTagName('td');
  	found = false;

    //Recorremos todas las celdas
    for (var j = 0; j < cellsOfRow.length && !found; j++) {
    	compareWith = cellsOfRow[j].innerHTML.toLowerCase();
      //Buscamos el texto en el contenido de la celda
      if (searchText.length == 0 || (compareWith.indexOf(searchText) > -1)) {
      	found = true;
      }
  }

  if(found) {
  	tableReg.rows[i].style.display = '';
  } else {
        //si no ha encontrado ninguna coincidencia, esconde la
        //fila de la tabla
        tableReg.rows[i].style.display = 'none';
    }
}
}
</script>

<!--Buscar Empleado-->
<script>function doSearch2() {
	var tableReg = document.getElementById('datos2');
	var searchText = document.getElementById('searchTerm2').value.toLowerCase();
	var cellsOfRow = "";
	var found = false;
	var compareWith = "";

  //Recorremos todas las filas con contenido de la tabla
  for (var i = 1; i < tableReg.rows.length; i++) {
  	cellsOfRow = tableReg.rows[i].getElementsByTagName('td');
  	found = false;

    //Recorremos todas las celdas
    for (var j = 0; j < cellsOfRow.length && !found; j++) {
    	compareWith = cellsOfRow[j].innerHTML.toLowerCase();
      //Buscamos el texto en el contenido de la celda
      if (searchText.length == 0 || (compareWith.indexOf(searchText) > -1)) {
      	found = true;
      }
  }

  if(found) {
  	tableReg.rows[i].style.display = '';
  } else {
        //si no ha encontrado ninguna coincidencia, esconde la
        //fila de la tabla
        tableReg.rows[i].style.display = 'none';
    }
}
}
</script>


</body>
</html>>