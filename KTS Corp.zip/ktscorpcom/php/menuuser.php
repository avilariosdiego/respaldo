<?php
  include_once('conexion/cnx.php');  //Agregando la Conexión a Base de Datos
  include_once('sesion.php');        //Agregando la Verificación de Sesión
  ?>
<div class="navbar navbar-expand navbar-dark sticky-top" style="background: #395784;">

  <a class="navbar-brand mr-1" href="paneluser.php" data-toggle="tooltip" title="Inicio">KTS Corp.</a>

  <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
    <i class="fas fa-bars" style="font-size: 18px;"></i>
  </button>

  <!--Navbar Search-->
  <div class="d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
    <a class="nabvar-brand text-white"><?php echo $_SESSION['nombre'].' '.$_SESSION['apellido']; ?></a>
  </div>

  <!--Navbar-->
  <ul class="navbar-nav ml-auto ml-md-0">
    <li class="nav-item">
    </li>
    <li class="nav-item">
      <a class="nav-link" href="csesion.php">
        <i class="fas fa-sign-out-alt" data-toggle="tooltip" title="Cerrar Sesión" style="font-size: 18px;"></i>
      </a>
    </li>
  </ul>
</div>

<div id="wrapper">

  <!--Sidebar-->
  <ul class="sidebar navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="cartas.php">
        <i class="fas fa-fw fa-file-alt"></i>
        <span>Cartas de Trabajo</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="formatos.php">
        <i class="fas fa-fw fa-file-pdf"></i>
        <span>Formatos</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="politicas.php">
        <i class="fas fa-fw fa-book"></i>
        <span>Políticas</span>
      </a>
    </li>
    <?php
    $querybuscarC = "SELECT * FROM usuarios";
    $QB = mysqli_query($cnx, $querybuscarC) or die(mysqli_error($cnx));
    if (mysqli_num_rows($QB) > 0 )
    {
      ?>
      <?php
      $nro = 0;
      while( $fila=mysqli_fetch_array($QB) )
      {
        $nro++;
        $idusuario = $fila['idusuario'];
        $nombre = utf8_decode($fila['nombre']);
        $apellido = utf8_decode($fila['apellido']);
        $cedula = $fila['cedula'];
        $idcargo = $fila['idcargo'];
        $idempresa = $fila['idempresa'];

        $cnx->set_charset("utf8");
        $querybuscarOP = " SELECT * FROM usuarios_cargo WHERE idcargo = '$idcargo' ";
        $QO = mysqli_query($cnx, $querybuscarOP) or die(mysqli_error($cnx));
        while (($fila=mysqli_fetch_array($QO)))
        {
          $descripcargo= $fila['descripcargo'];
        }

        $querybuscarEM = " SELECT * FROM usuarios_empresa WHERE idempresa = '$idempresa' ";
        $QEM = mysqli_query($cnx, $querybuscarEM) or die(mysqli_error($cnx));
        while (($fila=mysqli_fetch_array($QEM)))
        {
         $descripempresa= $fila['descripempresa'];
       }
       ?>
       <?php
     }
     ?>
     <?php
   }else{
    ?>
    <?php
  }
  ?>
  <li class="nav-item">
    <a class="nav-link" href="modificarclave.php?id=<?php echo $idusuario ?>">
      <i class="fas fa-fw fa-lock"></i>
      <span>Modificar Contraseña</span>
    </a>
  </li>
</ul>