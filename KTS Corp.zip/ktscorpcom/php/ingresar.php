<?php
session_start();
if(isset($_SESSION['autentificado'])){
	if($_SESSION['autentificado'] == true){

		if($_SESSION['opc_user'] == 'usuarios_admin')
		{
			header("Location: paneladmin.php");
		}elseif ($_SESSION['opc_user'] == 'usuarios') 
		{
			header("Location: paneluser.php");
		}
	}
}else{
	?>

	<!DOCTYPE html>
	<html lang="es">
	<head>
		<!--Metadatos y Datos-->
		<title>KTS Corp - Ingresar</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="icon" type="image/x-icon" href="../img/icono.png">

		<!--Local-->
		<link rel="stylesheet" type="text/css" href="../css/sesion.css">
		<link rel="stylesheet" type="text/css" href="../css/estilos.css">

		<!--Bootstrap-->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

		<!--Iconos-->
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	</head>
	<body>

		<!-- Load Facebook SDK for JavaScript -->
		<div id="fb-root"></div>
		<script>
			window.fbAsyncInit = function() {
				FB.init({
					xfbml            : true,
					version          : 'v3.3'
				});
			};

			(function(d, s, id) {
				var js, fjs = d.getElementsByTagName(s)[0];
				if (d.getElementById(id)) return;
				js = d.createElement(s); js.id = id;
				js.src = 'https://connect.facebook.net/es_LA/sdk/xfbml.customerchat.js';
				fjs.parentNode.insertBefore(js, fjs);
			}(document, 'script', 'facebook-jssdk'));</script>

			<!-- Your customer chat code -->
			<div class="fb-customerchat"
			attribution=setup_tool
			page_id="207937452626406"
			theme_color="#395784"
			logged_in_greeting="¡Hola! Haz olvidado tu contraseña?"
			logged_out_greeting="¡Hola! Haz olvidado tu contraseña?">
		</div>

		<!--Formulario de ingreso-->
		<form action="formingresar.php" name="ingresar" method="POST">

			<!--Logo-->
			<img src="../img/kts.png" class="img-fluid">

			<!--Cédula-->
			<div class="input-group">
				<div class="input-group-text">
					<span class="fas fa-user-circle" style="color: #395784;"></span>
				</div>
				<input type="text" id="cedula" name="cedula" class="form-control" placeholder="Cédula" maxlength="8" minlength="7">
			</div>

			<br>

			<!--Contraseña-->
			<div class="input-group">
				<div class="input-group-text">
					<span class="fas fa-lock" style="color: #395784;"></span>
				</div>
				<input type="password" id="contraseña" name="contraseña" class="form-control" placeholder="Contraseña" maxlength="16" minlength="8">
			</div>

			<br>

			<!--Tipo de Usuario-->
			<div class="input-group">
				<div class="input-group-text">
					<span class="fas fa-user-circle" style="color: #395784;"></span>
				</div>
				<select class="form-control" id="opctipo" name="opc_user">
					<option value="">Tipo de Usuario</option>
					<option value="usuarios_admin">Administrador</option>
					<option value="usuarios">Empleado</option>
				</select>
			</div>

			<br>

			<label>¿Olvidaste tu contraseña? Debes contactar al personal de Talento Humano mediante chat o en su defecto, personalmente.</label>

			<br>

			<!--Continuar-->
			<div id="enviar">
				<button type="button" name="continuar" id="continuar" class="btn btn-kts btn-block">Iniciar Sesión</button>
			</div>

			<br>

			<!--Regresar-->
			<a href="../index.php" style="text-decoration: none;"><button type="button" class="btn btn-kts btn-block">Regresar</button></a>
		</form>

		<!--JS-->
		<script src="../js/funciones.js"></script>
		<script src="../js/ingresar.js"></script>

	</body>
	</html>
	<?php
}
?>