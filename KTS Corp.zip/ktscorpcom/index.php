<?php
  include_once('php/conexion/cnx.php');  //Agregando la Conexión a Base de Datos
  ?>
  <!DOCTYPE html>
  <html lang="es">
  <head>
    <!--Metadatos y Datos-->
    <meta name="name" content="KTS Corp">
	<meta name="url" content="http://www.ktscorp.com">
	<meta name="description" content="El Grupo KTS Corp, es una empresa de asesoría y servicios profesionales; que asume el reto de utilizar el conocimiento y la tecnología como el motor principal">
    <meta name="keywords" content="KTS, Corp, Empresas, Servicios, Finanzas, Talento, Humano, Control, Gestion, Administracion, Soporte Tecnico, Max Ferrer, Anatel, Netdata">
    <meta name="copyright" content="KTS Corp">
    <meta name="Distribution" content="Global">
    <meta name="Rating" content="General">
    <meta name="Robots" content="INDEX,FOLLOW">
    <meta name="Revisit-after" content="7 days">
    <meta name="Language" content="Es">
    <meta http-equiv="Content-Language" content="Spanish">
    <meta name="DC.Language" scheme="RFC1766" content="Spanish">
    <meta http-equiv="Content-Language" content="es">
    <meta name="country" content="Venezuela">
    <meta name="geo.country" content="VE">
    <meta name="geo.region" content="VE-VE" />
    <meta name="geo.placename" content="Zulia" />
    <title>KTS Corp</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="img/icono.png">
    <meta name="google-site-verification" content="tNBeIcVWkv30Icg4UIkVyryeuNFup8GaFokVO0IM9f4">

    <!--Local-->
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
    <link rel="stylesheet" type="text/css" href="css/parallax.css">
    <link rel="stylesheet" type="text/css" href="css/popup.css">

    <!--Bootstrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <!--Iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.9.0/css/all.css">
  </head>
  <body id="page-top">

    <!-- Load Facebook SDK for JavaScript -->
    <div id="fb-root"></div>
    <script>
      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v3.3'
        });
      };

      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/es_LA/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

      <!-- Your customer chat code -->
      <div class="fb-customerchat"
      attribution=setup_tool
      page_id="207937452626406"
      theme_color="#395784"
      logged_in_greeting="¡Hola! ¿Cómo podemos ayudarte?"
      logged_out_greeting="¡Hola! ¿Cómo podemos ayudarte?">
    </div>

    <!--Símbolo de Carga-->
    <div id="contenedor_loader">
      <div class="loader text-center" id="loader">
        <img src="img/icono.png" width="100%">
      </div>
    </div>

    <!--Back to Top-->
    <div class="to-top box">
      <a class="back-to-top fas fa-chevron-up" href="#"></a>
    </div>

    <!--Menú-->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
      <div class="container-fluid">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">KTS Corp.</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="fas fa-bars text-white"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto my-2 my-lg-0">
            <li class="nav-item" style="padding-top: 10px;">
              <a class="nav-link js-scroll-trigger" href="#acerca">Acerca De</a>
            </li>
            <li class="nav-item" style="padding-top: 10px;">
              <a class="nav-link js-scroll-trigger" href="#servicios">Servicios</a>
            </li>
            <li class="nav-item" style="padding-top: 10px;">
              <a class="nav-link js-scroll-trigger" href="#clientes">Clientes</a>
            </li>
            <li class="nav-item" style="padding-top: 10px;">
              <a class="nav-link js-scroll-trigger" href="#contacto">Contacto</a>
            </li>
            <li class="nav-item text-white" style="padding-top: 10px;">
              <p>|</p>
            </li>
            <li class="nav-item" style="padding-top: 10px;">
              <a class="nav-link js-scroll-trigger" href="#" data-toggle="modal" data-target="#myModal"><strong>Ingresar</strong></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!--Encabezado-->
    <header class="masthead">
      <div class="container-fluid h-100">
        <div class="row h-100 align-items-center justify-content-center text-center">
          <div class="col-lg-10 align-self-end">
            <h1 class="text-uppercase text-white font-weight-bold">KTS CORP</h1>
            <hr class="divider my-4">
          </div>
          <div class="col-lg-8 align-self-baseline">
            <h2 class="text-white font-weight-light mb-5">Talento y dedicación a su servicio</h2>
            <a class="btn btn-kts js-scroll-trigger" href="#acerca"><strong>Saber Más</strong></a>
          </div>
        </div>
      </div>
    </header>

    <!--Acerca De-->
    <section class="page-section" id="acerca">
      <div class="container">
        <h2 class="text-center mt-0">Acerca De</h2>
        <hr class="divider my-4">
        <div class="row">
          <br>
          <div class="col-sm-8">
            <h2>Nuestra Empresa</h2><hr width="35%" align="left">

            <p>El Grupo KTS Corp, es una empresa de asesoría y servicios profesionales; que asume el reto de utilizar el conocimiento y la tecnología como el motor principal del cambio, el servicio como fórmula para cumplir una función creando vínculos y la autonomía como la convicción para crear iniciativas innovadoras.</p>

            <p>KTS Corp, C.A. es una organización integrada por empresas de tecnología, que reúnen talentos profesionales de primera línea, altamente motivados y que brindan una atención excepcional a cada Cliente, dedicados a respaldarlos en el éxito al frente de sus empresas y proyectos.</p>
          </div>

          <div class="col-sm-4 text-center">
            <i class="fas fa-building slideanim box" style="font-size: 120px; color: #395784;"></i>
          </div>
        </div>

        <br>

        <!--Misión y Visión-->
        <div class="row">
          <div class="col-sm-4 text-center">
            <i class="fas fa-globe slideanim box" style="font-size: 120px; color: #395784;"></i>
          </div>

          <div class="col-sm-8">
            <h2>Misión y Visión</h2><hr style="width: 40%"align="left" >
            <h5><strong>MISIÓN:</strong></h5>
            <p>Somos un equipo de líderes con visión estratégica, capaces de desarrollar y fortalecer unidades de negocios exitosas en el área de las tecnologías de información y comunicación en Latinoamérica, generando valor a colaboradores, accionistas y las comunidades donde operamos.</p>

            <h5><strong>VISIÓN:</strong></h5>
            <p>Ser una Corporación reconocida en Latinoamérica por maximizar la rentabilidad de empresas y emprendedores, potenciando sus Modelos de Negocios, a través de la tecnología de información y comunicación, apoyados en formas innovadoras en la gestión del talento humano.</p>
          </div>
        </div>

        <br>

        <!--Valores-->
        <h2>Nuestros Valores</h2>
        <hr style="width: 35%;" align="left">

        <div id="valores" class="carousel slide" data-ride="carousel">
          <!--The slideshow-->
          <div class="carousel-inner">

            <div class="carousel-item active">
              <div class="emprendimiento">
                <div class="carousel-caption" style="background-color: rgb(57, 87, 132, 0.5);">
                  <h4>Emprendimiento</h4>
                  <h6>Desarrollar y poner en marcha ideas innovadoras, aprovechando la tecnología y el conocimiento, aplicables tanto para modelos de negocio como para procesos establecidos. Proponer acciones innovadoras que permitan a la organización crecer, desarrollarse y expandirse.</h6>
                </div>
              </div>
            </div>

            <div class="carousel-item">
              <div class="servicio">
                <div class="carousel-caption" style="background-color: rgb(57, 87, 132, 0.5);">
                  <h4>Servicio</h4>
                  <h6>Es el arte de estar a disposición permanente del cliente, interno o externo, proveedores, comunidad y sociedad, indagando sus necesidades, con el fin de satisfacerlas superando sus expectativas.</h6>
                </div>
              </div>
            </div>

            <div class="carousel-item">
              <div class="responsabilidad">
                <div class="carousel-caption" style="background-color: rgb(57, 87, 132, 0.5);">
                  <h4>Responsabilidad</h4>
                  <h6>Capacidad para cumplir compromisos adquiridos y dar respuesta oportuna ante situaciones presentes. Cualidad que implica velar y dedicarse en el cumplimiento de los objetivos, ejecutar las tareas asignadas de acuerdo al rol, cuidando lo que se hace y dice.</h6>
                </div>
              </div>
            </div>

            <div class="carousel-item">
              <div class="compromiso">
                <div class="carousel-caption" style="background-color: rgb(57, 87, 132, 0.5);">
                  <h4>Compromiso</h4>
                  <h6>Capacidad de asumir los retos y responsabilidades con dedicación y lealtad.</h6>
                </div>
              </div>
            </div>

            <div class="carousel-item">
              <div class="respeto">
                <div class="carousel-caption" style="background-color: rgb(57, 87, 132, 0.5);">
                  <h4>Respeto</h4>
                  <h6>Compartir ideas, puntos de vista, opiniones con un enfoque múltiple, en un ambiente de cordialidad y de aceptación a la diversidad.</h6>
                </div>
              </div>
            </div>

            <div class="carousel-item">
              <div class="justicia">
                <div class="carousel-caption" style="background-color: rgb(57, 87, 132, 0.5);">
                  <h4>Justicia</h4>
                  <h6>Actuación equilibrada, trato equitativo y reconocimiento al mérito que promueve la paz organizacional.</h6>
                </div>
              </div>
            </div>

            <div class="carousel-item">
              <div class="trabajo">
                <div class="carousel-caption" style="background-color: rgb(57, 87, 132, 0.5);">
                  <h4>Trabajo en Equipo</h4>
                  <h6>Cualidad de mutua cooperación y flexibilidad, con roles claramente definidos, donde se desarrolla la sinergia para el logro de objetivos comunes.</h6>
                </div>
              </div>
            </div>
          </div>

          <!--Left and right controls-->
          <span class="carousel-control-prev" href="#valores" data-slide="prev">
            <span class="carousel-control fas fa-arrow-circle-left" style="font-size: 20px; color: #395784;"></span>
          </span>
          <span class="carousel-control-next" href="#valores" data-slide="next">
            <span class="carousel-control fas fa-arrow-circle-right" style="font-size: 20px; color: #395784;"></span>
          </span>
        </div>
      </div>
    </section>

    <!--Servicios-->
    <section class="page-section bg-light" id="servicios">
      <div class="container">
        <h2 class="text-center mt-0">Servicios</h2>
        <hr class="divider my-4">
        <br>
        <div class="row">
          <div class="col-lg-4 col-sm-6">
            <center><i class="fas fa-coins box" style="font-size: 100px; color: #395784;"></i></center>
            <br>
            <h2 class="text-center">Finanzas</h2>
            <hr>
            <ul class="text-left" style="padding-left: 20px;">
              <li>Revisión y aprobación de flujo de caja.</li>
              <li>Análisis y entrega de estados financieros.</li>
              <li>Monitoreo de cumplimiento de deberes formales.</li>
              <li>Supervisión de las Coordinaciones de administración, soporte técnico y talento humano.</li>
              <li>Asesoría, Consultoría y Auditoría de procesos.</li>
            </ul>
          </div>
          <div class="col-lg-4 col-sm-6">
            <center><i class="fas fa-tasks box" style="font-size: 100px; color: #395784;"></i></center>
            <br>
            <h2 class="text-center">Control y Gestión</h2>
            <hr>
            <ul class="text-left" style="padding-left: 20px;">
              <li>Seguimiento diario de ventas y cumplimiento de metas.</li>
              <li>Informes periodicos de estadística de ventas y compras.</li>
              <li>Seguimientos de objetivos estratégicos por departamento.</li>
              <li>Prestaciones de resultado de gestión.</li>
            </ul>
          </div>
          <div class="col-lg-4 col-sm-6">
            <center><i class="fas fa-wrench box" style="font-size: 100px; color: #395784;"></i></center>
            <br>
            <h2 class="text-center">Soporte Técnico</h2>
            <hr>
            <ul class="text-left" style="padding-left: 20px;">
              <li>Mantenimiento preventivo y correctivo</li>
              <li>Mantenimiento de aplicaciones y software.</li>
              <li>Administración de servidores, bases de datos, redes y software administrativos.</li>
              <li>Administración de requerimientos a nivel de usuarios.</li>
              <li>Control de usuarios y claves de acceso.</li>
              <li>Respaldo de datos.</li>
            </ul>        
          </div>
        </div>

        <br>

        <div class="row slideanim">
          <div class="col-lg-4 col-sm-6">
            <center><i class="fas fa-calculator box" style="font-size: 100px; color: #395784;"></i></center>
            <br>
            <h2 class="text-center">Administración</h2>
            <hr>
            <ul class="text-left" style="padding-left: 20px;">
              <li>Administración y control de los recursos financieros.</li>
              <li>Gestión de cuentas por cobrar y cuentas por pagar.</li>
              <li>Registro y control de ingresos y egresos.</li>
              <li>Gestión de servicios generales y recursos de mantenimiento.</li>
            </ul>
          </div>
          <div class="col-lg-4 col-sm-6">
            <center><i class="fas fa-users box" style="font-size: 100px; color: #395784;"></i></center>
            <br>
            <h2 class="text-center">Talento Humano</h2>
            <hr>
            <ul class="text-left" style="padding-left: 20px;">
              <li>Reclutamiento y selección de personal.</li>
              <li>Administración de beneficios.</li>
              <li>Desarrollo organizacional.</li>
              <li>Seguridad y salud laboral.</li>
              <li>Asesoría, Consultoría y Auditoría de procesos.</li>
            </ul>
          </div>
          <div class="col-lg-4 col-sm-6">
            <center><i class="fas fa-cubes box" style="font-size: 100px; color: #395784;"></i></center>
            <br>
            <h2 class="text-center">Procura y Logística</h2>
            <hr>
            <ul class="text-left" style="padding-left: 20px;">
              <li>Análisis de rotación de inventario.</li>
              <li>Procura de productos nacionales e importados.</li>
              <li>Recepción y despacho de mercancía.</li>
              <li>Control de inventario.</li>
            </ul>        
          </div>
        </div>
      </div>
    </section>

    <!--Clientes-->
    <section class="page-section" id="clientes">
      <div class="container">
        <h2 class="text-center mt-0">Clientes</h2>
        <hr class="divider my-4">
        <br>
        <div class="row text-center">
          <div class="col-lg-4 col-sm-6"><br>
            <img src="img/maxferrer.png" style="width: 190px;"><br><br>
            <h4>Max Ferrer</h4>
            <p>Su amigo eléctronico desde 1954</p>
            <button type="button" class="btn btn-outline-danger" data-toggle="modal" data-target="#myModal1" role="button" style="font-size: 18px;">Saber Más</button>
          </div>
          <div class="col-lg-4 col-sm-6"><br>
            <img src="img/kts.png" class="kts" style="width: 180px; background-color: #848584;"><br><br>
            <h4>KTS Corp</h4>
            <p>Talento y dedicación a su servicio</p>
            <button type="button" class="btn btn-outline-secondary" data-toggle="modal" data-target="#myModal2" role="button" style="font-size: 18px;">Saber Más</button>
          </div>
          <div class="col-lg-4 col-sm-6"><br>
            <img src="img/anatel.png" style="width: 190px;"><br><br>
            <h4>Anatel</h4>
            <p>Toda la red en un solo punto</p>
            <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#myModal3" role="button" style="font-size: 18px;">Saber Más</button>
          </div>
        </div>
        <br>
        <div class="row slideanim text-center">
          <div class="col-lg-4 col-sm-6"><br>
            <img src="img/neutron.png" style="width: 185px;"><br><br>
            <h4>Neutron</h4>
            <p>Más allá de la tecnología</p>
            <button type="button" class="btn btn-outline-dark" data-toggle="modal" data-target="#myModal4" role="button" style="font-size: 18px;">Saber Más</button>
          </div>
          <div class="col-lg-4 col-sm-6"><br><br>
            <img src="img/netdata.jpg" style="width: 220px;"><br><br><br>
            <h4>Netdata</h4>
            <p>Redes y soluciones de datos</p>
            <button type="button" class="btn btn-outline-success" data-toggle="modal" data-target="#myModal5" role="button" style="font-size: 18px;">Saber Más</button>
          </div>
          <div class="col-lg-4 col-sm-6"><br>
            <img src="img/mindforce.png" style="width: 230px;"><br><br>
            <h4>Mindforce</h4>
            <p>Tecnología Abierta Mindforce</p>
            <button type="button" class="btn btn-outline-warning" data-toggle="modal" data-target="#myModal6" role="button" style="font-size: 18px;">Saber Más</button>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!--Contacto-->
  <section class="page-section bg-light" id="contacto">
    <div class="container">
      <h2 class="text-center mt-0">Contacto</h2>
      <hr class="divider my-4">
      <br>
      <div class="row">
        <div class="col-lg-6 text-center slideanim">
          <i class="fas fa-address-card box" style="font-size: 200px; color: #395784;"></i>
        </div>

        <!--Formulario-->
        <div class="col-lg-6">
          <form action="php/formcontacto.php" id="contactos" name="contactos" method="POST" enctype="multipart/form-data">

            <!--Fila 1-->
            <div class="form-row">
              <div class="form-group col-md-4">
                <!--Nombre-->
                <div class="input-group">
                  <div class="input-group-text"><span class="fas fa-pencil-alt" style="color: #395784;" title="¡Aviso!" data-toggle="popover" data-trigger="hover" data-content="No dejes espacios vacíos en el campo."></span></div>
                  <input type="text" id="nombre" name="nombre" class="form-control" maxlength="16" placeholder="Nombre">
                </div>
              </div>

              <!--Apellido-->
              <div class="form-group col-md-4">
                <div class="input-group">
                  <div class="input-group-text"><span class="fas fa-pencil-alt" style="color: #395784;" title="¡Aviso!" data-toggle="popover" data-trigger="hover" data-content="No dejes espacios vacíos en el campo."></span></div>
                  <input type="text" id="apellido" name="apellido" class="form-control" maxlength="16" placeholder="Apellido">
                </div>
              </div>

              <!--Edad-->
              <div class="form-group col-md-4">
                <div class="input-group">
                  <div class="input-group-text"><span class="fas fa-calendar-check" style="color: #395784;" title="¡Aviso!" data-toggle="popover" data-trigger="hover" data-content="Debes ser mayor de 18 años."></span></div>
                  <select name="opc_edad" id="edad" class="form-control"> 
                    <option value="">Edad</option>
                    <?php for ($i=18; $i <= 60; $i++) { ?>
                      <option value="<?php echo $i ?>"><?php echo $i ?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
            </div>

            <!--Fila 2-->
            <!--Opciones-->
            <div class="input-group">
              <div class="input-group-text"><span class="fas fa-id-badge" style="color: #395784;" style="font-size: 20px;" title="¡Aviso!" data-toggle="popover" data-trigger="hover" data-content="Cada empresa tiene su propio cargo, no varía si solicitas empleo o pasantías académicas. Elige donde quieres trabajar y en que te especializas."></span></div>
              <select id="trabajo" name="opc_empresa" class="form-control">
                <option value="">Elige una opción</option>
                <option value="1">Finanzas y Contabilidad (KTS Corp)</option>
                <option value="2">Control y Gestión (KTS Corp)</option>
                <option value="3">Administración (KTS Corp - Max Ferrer - Anatel - Netdata)</option>
                <option value="4">Procura y Logística (KTS Corp - Max Ferrer - Anatel)</option>
                <option value="5">Talento Humano (KTS Corp)</option>
                <option value="6">Soporte Técnico (KTS Corp)</option>
                <option value="7">Operaciones e Implementación (Mindforce - Netdata)</option>
                <option value="8">Ventas (Max Ferrer - Anatel - Netdata)</option>
              </select>
            </div>

            <br>

            <!--Fila 3-->
            <div class="form-row">
              <!--Correo Electrónico-->
              <div class="form-group col-md-6">
                <div class="input-group">
                  <div class="input-group-text"><span class="fas fa-at" style="color: #395784;"></span></div>
                  <input type="email" id="email" name="email" class="form-control" maxlength="64" placeholder="Dirección de Correo Electrónico">
                </div>
              </div>

              <!--Número-->
              <div class="form-group col-md-6">
                <div class="input-group">
                  <div class="input-group-text"><span style="color: #395784;" title="¡Aviso!" data-toggle="popover" data-trigger="hover" data-content="Tu número debe contener 7 dígitos"><strong>+58</strong></span></div>
                  <select id="celular" name="num_codigo" class="form-control">
                    <option value="">Código</option>
                    <option value="1">414</option>
                    <option value="2">424</option>
                    <option value="3">416</option>
                    <option value="4">426</option>
                    <option value="5">412</option>
                  </select>
                  <input type="text" id="numero" name="numero" class="form-control" min="0" maxlength="7" placeholder="Número">
                </div>
              </div>
            </div>

            <!--Fila 4-->
            <!--Área de texto-->
            <textarea class="form-control txt-tam" rows="2" id="mensaje" name="txtmensaje" placeholder="¿Por que y donde te gustaría trabajar con nosotros? Puedes escribir tu resumen currícular en este campo." maxlength="500"></textarea>
            <br>

            <!--Fila 5-->
            <div class="form-row">
              <!--Radio-->
              <div class="form-group col-md-4">
                <label for="radio">Solicito:</label>
                <br>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" id="radio1" name="radio" value="1" checked>
                  <label class="form-check-label" for="radio1">Empleo</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" id="radio2" name="radio" value="2">
                  <label class="form-check-label" for="radio2">Pasantías</label>
                </div>
                <small id="radiomsj" class="form-text "></small>
              </div>

              <br>

              <!--Checkbox-->
              <div class="form-group col-md-4">
                <label for="checkbox">Comunicarse conmigo mediante:</label>
                <?php
                // Buscar los Checkbox en la Base de Datos
                $cnx->set_charset("utf8");
                $querybuscarChk = "SELECT * FROM contacto_checkboxs";
                $QB = mysqli_query($cnx, $querybuscarChk) or die(mysqli_error($cnx));
                while (($fila=mysqli_fetch_array($QB)))
                {
                  $idchk = $fila['idchk'];
                  $descripchk = $fila['descripchk'];
                  if($descripchk == 'E-mail'){
                    ?>
                    <div class="form-check form-check-inline">
                      <input type="checkbox" id="<?php echo $descripchk?>" name="checkbox[]" value="<?php echo $idchk?>" class="form-check-input" title="Sugerencia" data-toggle="popover" data-trigger="hover" data-content="Habilita esta casilla para comunicarnos contigo!" checked>
                      <label class="form-check-label" for="<?php echo $descripchk?>"><?php echo $descripchk ?></label>
                    </div>
                    <?php
                  }else{
                    ?>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="checkbox" id="<?php echo $descripchk?>" name="checkbox[]" value="<?php echo $idchk?>">
                      <label class="form-check-label" for="<?php echo $descripchk?>"><?php echo $descripchk ?></label>
                    </div>
                    <?php
                  }
                }
                ?>
                <small id="chkmsj" class="form-text "></small>
              </div>
              
              <br>

              <!--Archivos-->
              <div class="form-group col-md-4">
                <input type="file" id="archivo" name="archivo" class="form-control-file" accept=".doc,.docx,.pdf" title="Sugerencia" data-toggle="popover" data-trigger="hover" data-content="Puedes adjuntar aquí tu currículum, pero recomendamos que lo envies al correo: talentohumano@ktscorp.com para obtener una respuesta más rápida."><small id="archivomsj" class="form-text "></small>
                <span style="color: #848584; font-size: 13px;">Subida 2mb máximo (.docx ó .pdf)</span>
              </div>
            </div>

            <br>

            <!--Enviar-->
            <div id="envio">
              <button type="button" name="enviar" id="enviar" class="btn btn-kts btn-block slideanim">Enviar Datos</button>
            </div>
          </form>
          <br>
        </div>
      </div>
    </div>
  </div>
</section>

<!--Maps-->
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3920.9074442244946!2d-71.62021868565058!3d10.66429199239772!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e8998e223704fc7%3A0x8d02f85ebc02727c!2sKTS+Corp!5e0!3m2!1ses-419!2sve!4v1533240988811" width="100%" height=200px frameborder="0" allowfullscreen></iframe>

<!--Pie de Página-->
<footer class="font-small" style="background-color: #848584;">

  <div style="background-color: #395784;">
    <div class="container text-white">
      <div class="row py-4 d-flex align-items-center">
        <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
          <h6 class="mb-0">Talento y Dedicación a su Servicio</h6>
        </div>
        <div class="col-md-6 col-lg-7 text-center text-md-right">
          <!--instagram maxferrer-->
          <a href="https://www.instagram.com/amigomaxferrer/" data-toggle="tooltip" title="Instagram de Max Ferrer" target="_blank">
            <i class="fab fa-instagram text-danger box" style="font-size:24px; text-decoration: none;"></i>
          </a>
          &nbsp;&nbsp;
          <!--facebook netdata-->
          <a href="https://www.facebook.com/netdatanetworks/" data-toggle="tooltip" title="Facebook de Netdata" target="_blank">
            <i class="fab fa-facebook text-success box" style="font-size:24px; text-decoration: none;"></i>
          </a>
          <!--instagram netdata-->
          <a href="https://www.instagram.com/netdatanetworks/" data-toggle="tooltip" title="Instagram de Netdata" target="_blank">
            <i class="fab fa-instagram text-success box" style="font-size:24px; text-decoration: none;"></i>
          </a>
          &nbsp;&nbsp;
          <!--instagram anatel-->
          <a href="https://www.instagram.com/anatelredes/" data-toggle="tooltip" title="Instagram de Anatel" target="_blank">
            <i class="fab fa-instagram text-primary box" style="font-size:24px; text-decoration: none;"></i>
          </a>
        </div>
      </div>
    </div>
  </div>

  <!--contenido-->
  <div class="container text-center text-md-left mt-5 text-white">
    <div class="row mt-3">
      <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
        <!--KTS Corp-->
        <h6 class="text-uppercase font-weight-bold">KTS Corp C.A.</h6>
        <hr class="accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>Es una organización integrada por empresas de tecnología, que reúnen talentos profesionales que brindan una atención excepcional a cada Cliente, dedicados a respaldarlos en el éxito al frente de sus empresas y proyectos.</p>
      </div>

      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
        <!--Acerca De-->
        <h6 class="text-uppercase font-weight-bold">Acerca De</h6>
        <hr class="accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p><a href="legal/politicas_de_privacidad.html" target="_blank" style="color: #fff;">Políticas de Privacidad</a></p>
        <p><a href="legal/terminos_condiciones.html" target="_blank" style="color: #fff;">Términos y Condiciones de Uso</a></p>
      </div>

      <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
        <!--Clientes-->
        <h6 class="text-uppercase font-weight-bold">Clientes</h6>
        <hr class="accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p><a href="http://anatelve.com/" target="_blank" style="color: #fff;">Anatel C.A.</a></p>
        <p><a href="http://maxferrerve.com/" target="_blank" style="color: #fff;">Max Ferrer C.A.</a></p>
        <p><a href="#clientes" class="js-scroll-trigger" style="color: #fff;">MindForce C.A.</a></p>
        <p><a href="https://www.netdatanetworks.com/" target="_blank" style="color: #fff;">Netdata C.A.</a></p>
        <p><a href="#clientes" class="js-scroll-trigger" style="color: #fff;">Neutron C.A.</a></p>
      </div>

      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
        <!--Contacto-->
        <h6 class="text-uppercase font-weight-bold">Contacto</h6>
        <hr class="accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p><i class="fas fa-home mr-3"></i>Calle 77 entre Av.14A y 15. Edificio 5 de julio.</p>
        <p><i class="fas fa-envelope mr-3"></i>talentohumano@ktscorp.com</p>
        <p><i class="fas fa-phone mr-3"></i>+58 2617987196</p>
      </div>
    </div>
  </div>

  <!--Copyright-->
  <div class="text-center py-3 text-white" style="background-color: #395784;">&copy; <span id="output"></span> KTS Corp - Todos los derechos reservados | Desarrollado Por <a href="http://avilariosdiego.github.io/daar/" target="_blank" class="daar">Diego Avila</a></div>

</footer>

<!--Modales-->
<!--Ingresar-->
<div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <!--Modal Header-->
      <div class="modal-header">
        <h4 class="modal-title">¡Alerta! Solo personal autorizado <i class="fas fa-exclamation-triangle" style="font-size:20px; color: #ffae42;"></i></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!--Modal body-->
      <div class="modal-body">
        <h5>Uso Exclusivo del personal de KTS Corp. y sus empresas aliadas <i class="fas fa-users" style="font-size:20px; color: #395784;"></i></h5>
      </div>
      <!--Modal footer-->
      <div class="modal-footer">
        <a href="php/ingresar.php"><button type="button" class="btn btn-kts">Ingresar</button></a>
      </div>
    </div>
  </div>
</div>

<!--Max Ferrer-->
<div class="modal fade" id="myModal1">
  <div class="modal-dialog">
    <div class="modal-content">
      <!--Modal Header-->
      <div class="modal-header">
        <h4 class="modal-title">Max Ferrer</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!--Modal body-->
      <div class="modal-body">
        <h5>Nuestra empresa es bien conocida por sus precios convenientes, calidad de productos y atención personalizada al cliente.
          <br><br>
        Nos caracterizamos por ser una empresa pujante, que incorpora de manera constante novedades y diversas opciones para cubrir las necesidades de cada cliente y los mejores precios, sumado a un excelente servicio.</h5>
      </div>
      <!--Modal footer-->
      <div class="modal-footer">
        <a href="http://maxferrerve.com/" target="_blank"><button type="button" class="btn btn-outline-danger">Visitar</button></a>
      </div>
    </div>
  </div>
</div>

<!--KTS Corp-->
<div class="modal fade" id="myModal2">
  <div class="modal-dialog">
    <div class="modal-content">
      <!--Modal Header-->
      <div class="modal-header">
        <h4 class="modal-title">KTS Corp</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!--Modal body-->
      <div class="modal-body">
        <h6>Las cinco empresas están vinculadas por su composición accionaria, y operacionalmente, por:
          <br><br>
          <i class="fas fa-check" style="font-size:20px; color: #395784;"></i> Una misma filosofía y estilo gerencial autónomo orientado a &nbsp;&nbsp;&nbsp;&nbsp; la productividad.<br>
          <i class="fas fa-check" style="font-size:20px; color: #395784;"></i> La combinación del conocimiento, la tecnología y el &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;servicio, para la generación de iniciativas  exitosas.<br>
          <i class="fas fa-check" style="font-size:20px; color: #395784;"></i> La complementariedad de sus negocios o nichos de &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;mercado.<br>
          <i class="fas fa-check" style="font-size:20px; color: #395784;"></i> Su potencial de crecimiento.
          <br><br>
          Nuestras empresas operan en el mercado nacional e Internacional con:
          <br><br>
          <i class="fas fa-check" style="font-size:20px; color: #395784;"></i> Proyectos de expansión progresiva a otras regiones.<br>
          <i class="fas fa-check" style="font-size:20px; color: #395784;"></i> Conexión internacional para garantizar los suministros.<br>
          <i class="fas fa-check" style="font-size:20px; color: #395784;"></i> Propósitos de expansión a otras localidades internacionales.</h6>
        </div>
        <!--Modal footer-->
        <div class="modal-footer">
          <a href=""><button type="button" class="btn btn-outline-secondary"  data-dismiss="modal">Cerrar</button></a>
        </div>
      </div>
    </div>
  </div>

  <!--Anatel-->
  <div class="modal fade" id="myModal3">
    <div class="modal-dialog">
      <div class="modal-content">
        <!--Modal Header-->
        <div class="modal-header">
          <h4 class="modal-title">Anatel</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <!--Modal body-->
        <div class="modal-body">
          <h5>Una red de tiendas al mayor y detal a nivel Nacional e Internacional, basadas en el concepto “One Stop Networking” toda la red en un solo punto: 
            <br><br>
          Anatel constituye un espacio físico y de relación, donde el cliente tiene a su disposición todo lo que pueda requerir para desarrollar, instalar y mantener una red de Voz, Data y Video, alámbrica o inalámbrica.</h5>
        </div>
        <!--Modal footer-->
        <div class="modal-footer">
          <a href="http://anatelve.com/" target="_blank"><button type="button" class="btn btn-outline-primary">Visitar</button></a>
        </div>
      </div>
    </div>
  </div>

  <!--Neutron-->
  <div class="modal fade" id="myModal4">
    <div class="modal-dialog">
      <div class="modal-content">
        <!--Modal Header-->
        <div class="modal-header">
          <h4 class="modal-title">Neutron</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <!--Modal body-->
        <div class="modal-body">
          <h5>Neutron C.A. es una empresa Venezolana con mas de 26 años de experiencia en el mercado venezolano, la cual se dedica a proveer soluciones el área de informática y telecomunicaciones con personal altamente calificado.</h5>
        </div>
        <!--Modal footer-->
        <div class="modal-footer">
          <a href=""><button type="button" class="btn btn-outline-dark" data-dismiss="modal">Cerrar</button></a>
        </div>
      </div>
    </div>
  </div>

  <!--Netdata-->
  <div class="modal fade" id="myModal5">
    <div class="modal-dialog">
      <div class="modal-content">
        <!--Modal Header-->
        <div class="modal-header">
          <h4 class="modal-title">Netdata</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <!--Modal body-->
        <div class="modal-body">
          <h5>Netdata es una  empresa proveedora de Soluciones de Redes IP con personal altamente calificado que apoya a sus clientes en: Planificación, Diseño, Implementación, Migración, Operación y Optimización.
            <br><br> 
          Nuestra estrategia busca aumentar sus ingresos a través de la prestación de nuevos y mejores servicios, optimizar sus costos operativos, y elevar los niveles de satisfacción y lealtad de los clientes.</h5>
        </div>
        <!--Modal footer-->
        <div class="modal-footer">
          <a href="https://www.netdatanetworks.com/" target="_blank"><button type="button" class="btn btn-outline-success">Visitar</button></a>
        </div>
      </div>
    </div>
  </div>

  <!--Mindforce-->
  <div class="modal fade" id="myModal6">
    <div class="modal-dialog">
      <div class="modal-content">
        <!--Modal Header-->
        <div class="modal-header">
          <h4 class="modal-title">Mindforce</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <!--Modal body-->
        <div class="modal-body">
          <h5>Líder en Venezuela de soluciones de múltiples proveedores en el mercado de infraestructura de comunicaciones. La compañía ha aumentado en alcance y profundidad, evolucionando en respuesta a los cambios del mercado. Con sede en Caracas Venezuela.
            <br><br>
          La empresa suministra a los principales fabricantes de equipos y operadores móviles con una gama completa de servicios modulares. Esto incluye el suministro, outsourcing de procura y diseño, instalación y puesta en servicio de redes de telecomunicaciones</h5>
        </div>
        <!--Modal footer-->
        <div class="modal-footer">
          <a href=""><button type="button" class="btn btn-outline-warning" data-dismiss="modal">Cerrar</button></a>
        </div>
      </div>
    </div>
  </div>

  <!--Cookies-->
  <div class=" fixed-bottom alert text-center cookiealert">
    <small>Este sitio web utiliza cookies para que usted tenga la mejor experiencia de usuario. Si continúa navegando está dando su consentimiento para la aceptación de las mencionadas cookies y la aceptación de nuestra política de cookies.</small>
    <a href="legal/politicas_de_privacidad.html" style="text-decoration: none;" class="btn btn-kts btn-sm" target="_blank"> Saber Más</a>
    <button class="btn btn-kts btn-sm acceptcookies" aria-label="Close"> Aceptar</button>
  </div>

  <!--JS-->
  <script src="js/funciones.js"></script>
  <script src="js/easing.js"></script>
  <script src="js/contacto.js"></script>
  <script src="js/popup.js"></script>

</body>
</html>