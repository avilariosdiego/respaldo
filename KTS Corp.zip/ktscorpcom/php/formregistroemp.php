<?php
    //Validando que exista el boton de envío
    if ( isset($_POST['registrar']) ){
        //Incluyendo la conexión a la Base De Datos
        include_once('conexion/cnx.php');
        //Captando el valor de los campos en el formulario
        $nombre     = $_POST['nombre'];
        $apellido   = $_POST['apellido'];
        $cedula     = $_POST['cedula'];
        $cargo      = $_POST['cargo'];
        $empresa    = $_POST['empresa'];
        $contraseña = md5($_POST['contraseña']);

        // Verificando que no se registre una cedula repetida
        $Q = " SELECT * FROM usuarios WHERE cedula = '$cedula' ";
        $VC = mysqli_query($cnx, $Q) or die(mysqli_error($cnx));
        $countRQ = mysqli_num_rows($VC);
        if($countRQ == 1){
		    echo '<script>
                location.href="registraremp.php";
                alert("La cédula ingresada ya se encuentra registrada");
		        </script>';
        }
        
        //Validando que exista algún valor en los campos
        if (empty($nombre) || empty($apellido) || empty($cedula) || empty($cargo) || empty($empresa) || empty($contraseña) )
        {
            echo '<script> alert("Algunos campos se encuentran vacíos"); location.href="registraremp.php"; </script>';
        }else{
            //Insertando datos en la tabla de Usuarios
            $queryInsertarD = "INSERT INTO usuarios ( idusuario, nombre, apellido, cedula, idcargo, idempresa, clave ) values ( null , '$nombre', '$apellido', '$cedula', '$cargo', '$empresa', '$contraseña' )";
            $QI1 = mysqli_query($cnx, $queryInsertarD) or die(mysqli_error($cnx));
        }

        //Mensaje verificando que se guardaron los datos
        if($QI1 == true){
            echo '<script> alert("Usuario empleado se ha creado con éxito"); location.href="registraremp.php"; </script>';
        }
        
    }

?>