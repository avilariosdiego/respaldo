<?php
    $server = 'localhost';
    $user = 'ktsuser';
    $passw = 'ktscorp';
    $dbname = 'ktsdb';

    $cnx = mysqli_connect($server,$user,$passw,$dbname);

    if(!$cnx){
	    die(mysqli_error($cnx));
    }
?>