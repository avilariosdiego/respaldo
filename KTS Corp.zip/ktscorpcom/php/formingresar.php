<?php

    $cedula      = $_POST['cedula'];
    $contraseña  = md5($_POST['contraseña']);
    $opc_user    = $_POST['opc_user'];
    
    if( isset($opc_user) && 
        isset($cedula) && 
        isset($contraseña) && 
        !empty($opc_user) && 
        !empty($cedula) && 
        !empty($contraseña) ){

        include_once('conexion/cnx.php');

        $Q = " SELECT * FROM $opc_user WHERE cedula='$cedula' AND clave='$contraseña' ";
        $RQ = mysqli_query($cnx, $Q) or die(mysqli_error($cnx));
        $countRQ = mysqli_num_rows($RQ);

	    if($countRQ == 0){
		    echo '<script>
                location.href="ingresar.php";
                alert("Cédula y/o contraseña inválidas!");
		        </script>';
	    }

	    if($countRQ == 1){
            session_start();

            $PD = " SELECT * FROM $opc_user WHERE cedula='$cedula' ";
            $PDM = mysqli_query($cnx, $PD) or die(mysqli_error($cnx));
            while ( $fila=mysqli_fetch_array($PDM) )
		    {
                $_SESSION['nombre'] = $fila['nombre'];
                $_SESSION['apellido'] = $fila['apellido'];
		    }

            $_SESSION['autentificado'] = true;
            $_SESSION['opc_user'] = $opc_user;
            $_SESSION['cedula'] = $cedula;

            if($opc_user == 'usuarios_admin')
            {
                header("Location: paneladmin.php");

            }elseif ($opc_user == 'usuarios') 
            {
                header("Location: paneluser.php");
            }
	    }

    }else{

	echo '<script>
	    alert("Cédula y/o contraseña vacíos o invalidos!");
	    location.href="ingresar.php";
	    </script>';
    }

    mysqli_close($cnx);
?>