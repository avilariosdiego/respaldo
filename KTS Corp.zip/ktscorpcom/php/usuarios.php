﻿<?php
  include_once('conexion/cnx.php');  //Agregando la Conexión a Base de Datos
  include_once('sesion.php');        //Agregando la Verificación de Sesión
  ?>
  <!DOCTYPE html>
  <html lang="es">
  <head>
    <!--Metadatos y Datos-->
    <title>KTS Corp - Mostrar Usuarios</title>
    <meta charset="utf-8">
    <meta name="KTS Corp" content="Extranet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="../img/icono.png">

    <!--Local-->
    <link rel="stylesheet" type="text/css" href="../css/estilos.css">
    <link rel="stylesheet" type="text/css" href="../css/sidebar.css">

    <!--Bootstrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <!--Iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  </head>
  <body>

    <!-- Load Facebook SDK for JavaScript -->
    <div id="fb-root"></div>
    <script>
      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v3.3'
        });
      };

      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/es_LA/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

      <!-- Your customer chat code -->
      <div class="fb-customerchat"
      attribution=setup_tool
      page_id="207937452626406"
      theme_color="#395784"
      logged_in_greeting="¡Hola! Necesitas ayuda con algo?"
      logged_out_greeting="¡Hola! Necesitas ayuda con algo?">
    </div>

    <!--Menú-->
    <?php
    include_once('menuadmin.php');
    ?>

    <div id="content-wrapper">
      <div class="container">
        <hr>
        <div class="row">
          <div class="col-lg-4 col-sm-6">
            <form class="text-center">
              <div class="input-group">
                <div class="input-group-text">
                  <span class="fas fa-search" style="color: #395784;"></span>
                </div>
                <input id="searchTerm" type="text" onkeyup="doSearch()" class="form-control" placeholder="Buscar Administrador" aria-label="Search" aria-describedby="basic-addon2">
              </div>
            </form>
          </div>
          <div class="col-lg-4 col-sm-6 text-center">
            <code>Buscar por: Nombre, Apellido, Cédula, Cargo y Compañia.</code>
          </div>
          <div class="col-lg-4 col-sm-6">
            <a href="excel.php" style="text-decoration: none !important;">
              <button class="btn btn-kts btn-block">Exportar a Excel <i class="fas fa-print"></i>
              </button>
            </a>
          </div>
        </div>
        <!--Mostrar Usuarios Administradores-->
        <div class="container text-center">
          <br>
          <div class="row text-center">
            <div class="col-sm-4">
              <hr>
            </div>
            <div class="col-sm-4">
              <h4 class="text-center text-dark box">ADMINISTRADORES</h4>
            </div>
            <div class="col-sm-4">
              <hr>
            </div>
          </div>
          <br>
          <?php
          $querybuscarC = "SELECT * FROM usuarios_admin";
          $QB = mysqli_query($cnx, $querybuscarC) or die(mysqli_error($cnx));
          if (mysqli_num_rows($QB) > 0 )
          {
            ?>
            <div class="container table-responsive">
              <table class="table table-hover table-bordered" id="datos">
                <thead>
                  <tr>
                    <th><strong>N°</strong></th>
                    <th><strong>Nombre</strong></th>
                    <th><strong>Apellido</strong></th>
                    <th><strong>Cédula</strong></th>
                    <th><strong>Cargo</strong></th>
                    <th><strong>Compañia</strong></th>
                    <th><strong>Modificar</strong></th>
                    <th><strong>Eliminar</strong></th>
                  </tr>
                </thead>
                <?php
                $nro = 0;
                while( $fila=mysqli_fetch_array($QB) )
                {
                  $nro++;
                  $idadmin = $fila['idadmin'];
                  $nombre = $fila['nombre'];
                  $apellido = $fila['apellido'];
                  $cedula = $fila['cedula'];
                  $idcargo = $fila['idcargo'];
                  $idempresa = $fila['idempresa'];
                  
                  $cnx->set_charset("utf8");
                  $querybuscarOP = " SELECT * FROM usuarios_cargo WHERE idcargo = '$idcargo' ";
                  $QO = mysqli_query($cnx, $querybuscarOP) or die(mysqli_error($cnx));
                  while (($fila=mysqli_fetch_array($QO)))
                  {
                    $descripcargo= $fila['descripcargo'];
                  }
                  
                  $querybuscarEM = " SELECT * FROM usuarios_empresa WHERE idempresa = '$idempresa' ";
                  $QEM = mysqli_query($cnx, $querybuscarEM) or die(mysqli_error($cnx));
                  while (($fila=mysqli_fetch_array($QEM)))
                  {
                   $descripempresa= $fila['descripempresa'];
                 }
                 ?>
                 <tbody id="datos">
                  <tr>
                    <td><?php echo $nro ?></td>
                    <td><?php echo $nombre ?></td>
                    <td><?php echo $apellido ?></td>
                    <td><?php echo $cedula ?></td>
                    <td><?php echo $descripcargo ?></td>
                    <td><?php echo $descripempresa ?></td>
                    <td><a class="btn btn-kts" href="modificaradmin.php?id=<?php echo $idadmin ?>"><span class="fas fa-user-edit"></span></a></td>
                    <td><a class="btn btn-kts" href="#" onclick="preguntaradmin(<?php echo $idadmin ?>)"><span class="fas fa-user-times"></span></a></td>
                  </tr>
                </tbody>
                <?php
              }
              ?>
            </table>
            <?php
          }
          ?>
        </div>
      </div>

      <hr>

      <div class="row">
        <div class="col-lg-6">
          <form class="text-center">
            <div class="input-group">
              <div class="input-group-text">
                <span class="fas fa-search" style="color: #395784;"></span>
              </div>
              <input id="searchTerm2" type="text" onkeyup="doSearch2()" class="form-control" placeholder="Buscar Empleado" aria-label="Search" aria-describedby="basic-addon2">
            </div>
          </form>
        </div>
        <div class="col-lg-6 text-center">
          <code>Buscar por: Nombre, Apellido, Cédula, Cargo y Compañia.</code>
        </div>
      </div>

      <!--Mostrar Usuarios Empleados-->
      <div class="container text-center">
        <br>
        <div class="row text-center">
          <div class="col-sm-4">
            <hr>
          </div>
          <div class="col-sm-4">
            <h4 class="text-center text-dark box">EMPLEADOS</h4>
          </div>
          <div class="col-sm-4">
            <hr>
          </div>
        </div>
        <br>
        <?php
        $querybuscarC = "SELECT * FROM usuarios";
        $QB = mysqli_query($cnx, $querybuscarC) or die(mysqli_error($cnx));
        if (mysqli_num_rows($QB) > 0 )
        {
          ?>
          <div class="container table-responsive">
            <table class="table table-hover table-bordered" id="datos2">
              <thead>
                <tr>
                  <td><strong>N°</strong></td>
                  <td><strong>Nombre</strong></td>
                  <td><strong>Apellido</strong></td>
                  <td><strong>Cédula</strong></td>
                  <td><strong>Cargo</strong></td>
                  <td><strong>Compañia</strong></td>
                  <td><strong>Modificar</strong></td>
                  <td><strong>Eliminar</strong></td>
                </tr>
              </thead>
              <?php
              $nro = 0;
              while( $fila=mysqli_fetch_array($QB) )
              {
                $nro++;
                $idusuario = $fila['idusuario'];
                $nombre = utf8_decode($fila['nombre']);
                $apellido = utf8_decode($fila['apellido']);
                $cedula = $fila['cedula'];
                $idcargo = $fila['idcargo'];
                $idempresa = $fila['idempresa'];
                
                $cnx->set_charset("utf8");
                $querybuscarOP = " SELECT * FROM usuarios_cargo WHERE idcargo = '$idcargo' ";
                $QO = mysqli_query($cnx, $querybuscarOP) or die(mysqli_error($cnx));
                while (($fila=mysqli_fetch_array($QO)))
                {
                  $descripcargo= $fila['descripcargo'];
                }
                
                $querybuscarEM = " SELECT * FROM usuarios_empresa WHERE idempresa = '$idempresa' ";
                $QEM = mysqli_query($cnx, $querybuscarEM) or die(mysqli_error($cnx));
                while (($fila=mysqli_fetch_array($QEM)))
                {
                 $descripempresa= $fila['descripempresa'];
               }
               ?>
               <tbody id="datos">
                <tr>
                  <td><?php echo $nro ?></td>
                  <td><?php echo $nombre ?></td>
                  <td><?php echo $apellido ?></td>
                  <td><?php echo $cedula ?></td>
                  <td><?php echo $descripcargo ?></td>
                  <td><?php echo $descripempresa ?></td>
                  <td><a class="btn btn-kts" href="modificaruser.php?id=<?php echo $idusuario ?>"><span class="fas fa-user-edit"></span></a></td>
                  <td><a class="btn btn-kts" href="#" onclick="preguntaruser(<?php echo $idusuario ?>)"><span class="fas fa-user-times"></span></a></td>
                </tr>
              </tbody>
              <?php
            }
            ?>
          </table>
          <?php
        }else{
          ?>
          <h4>POR LOS MOMENTOS NO HAY NINGÚN USUARIO DE EMPLEADO</h4>
          <?php
        }
        ?>
      </div>
    </div>
    <footer class="sticky-footer">
      <div class="container my-auto">
        <div class="copyright text-center my-auto">
          © <span id="output"></span> | KTS Corp - Todos los derechos reservados | RIF J-29454989-6
        </div>
      </div>
    </footer>
  </div>
</div>

<!--JS-->
<script src="../js/funciones.js"></script>
<script src="../js/sidebar.js"></script>
<script>
  function preguntaradmin(idadmin){
    if(confirm('¿Está seguro que desea eliminar el usuario seleccionado?'))
    {
      window.location.href = "eliminaradmin.php?id="+idadmin; 
    }
  }

  function preguntaruser(idusuario){
    if(confirm('¿Está seguro que desea eliminar el usuario seleccionado?'))
    {
      window.location.href = "eliminaruser.php?id="+idusuario; 
    }
  }
</script>

<!--Buscar Administrador-->
<script>
  function doSearch() {
    var tableReg = document.getElementById('datos');
    var searchText = document.getElementById('searchTerm').value.toLowerCase();
    var cellsOfRow = "";
    var found = false;
    var compareWith = "";
    
  //Recorremos todas las filas con contenido de la tabla
  for (var i = 1; i < tableReg.rows.length; i++) {
    cellsOfRow = tableReg.rows[i].getElementsByTagName('td');
    found = false;

    //Recorremos todas las celdas
    for (var j = 0; j < cellsOfRow.length && !found; j++) {
      compareWith = cellsOfRow[j].innerHTML.toLowerCase();
      //Buscamos el texto en el contenido de la celda
      if (searchText.length == 0 || (compareWith.indexOf(searchText) > -1)) {
        found = true;
      }
    }

    if(found) {
      tableReg.rows[i].style.display = '';
    } else {
        //si no ha encontrado ninguna coincidencia, esconde la
        //fila de la tabla
        tableReg.rows[i].style.display = 'none';
      }
    }
  }
</script>

<!--Buscar Empleado-->
<script>function doSearch2() {
  var tableReg = document.getElementById('datos2');
  var searchText = document.getElementById('searchTerm2').value.toLowerCase();
  var cellsOfRow = "";
  var found = false;
  var compareWith = "";
  
  //Recorremos todas las filas con contenido de la tabla
  for (var i = 1; i < tableReg.rows.length; i++) {
    cellsOfRow = tableReg.rows[i].getElementsByTagName('td');
    found = false;

    //Recorremos todas las celdas
    for (var j = 0; j < cellsOfRow.length && !found; j++) {
      compareWith = cellsOfRow[j].innerHTML.toLowerCase();
      //Buscamos el texto en el contenido de la celda
      if (searchText.length == 0 || (compareWith.indexOf(searchText) > -1)) {
        found = true;
      }
    }

    if(found) {
      tableReg.rows[i].style.display = '';
    } else {
        //si no ha encontrado ninguna coincidencia, esconde la
        //fila de la tabla
        tableReg.rows[i].style.display = 'none';
      }
    }
  }
</script>


</body>
</html>