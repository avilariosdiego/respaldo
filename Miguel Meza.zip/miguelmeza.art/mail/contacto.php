<?php

if(empty($_POST['name'])      ||
   empty($_POST['email'])     ||
   empty($_POST['phone'])     ||
   empty($_POST['message'])   ||
   !filter_var($_POST['email'],FILTER_VALIDATE_EMAIL))
   {
   echo "No hay argumentos proporcionados!";
   return false;
   }
   
$name = strip_tags(htmlspecialchars($_POST['name']));
$email_address = strip_tags(htmlspecialchars($_POST['email']));
$phone = strip_tags(htmlspecialchars($_POST['phone']));
$message = strip_tags(htmlspecialchars($_POST['message']));
   
$to = 'miguelangelmezar@gmail.com';
$email_subject = "Contacto Miguel Meza:  $name";
$email_body = "Tu has recibido un nuevo mensaje de contacto de Miguel Meza.\n\n"."Aquí para más detalles:\n\nNombre: $name\n\nE-mail: $email_address\n\nTeléfono: $phone\n\nMensaje:\n$message";
$headers = "From: miguelangelmezar@gmail.com\n";
$headers .= "Reply-To: $email_address";   
mail($to,$email_subject,$email_body,$headers);
return true;         
?>