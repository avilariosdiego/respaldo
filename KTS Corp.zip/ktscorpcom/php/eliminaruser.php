<?php
	include_once('conexion/cnx.php');  //Agregando la Conexión a Base de Datos
	include_once('sesion.php');        //Agregando la Verificación de Sesión

    $idusuario = $_REQUEST['id'];	  //Captando el valor del id

    //Eliminar de la Base de Datos el Usuario Administrador
	$queryEliminarA = "DELETE FROM usuarios WHERE idusuario = '$idusuario'";
    $QEE = mysqli_query($cnx, $queryEliminarA) or die(mysqli_error($cnx));

    if ($QEE == true)
    {
        echo '<script> location.href="usuarios.php"; </script>';
    }
?>