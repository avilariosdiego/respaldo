<?php
	//error_reporting(E_ERROR | E_PARSE);
	session_start();

	if(!$_SESSION['autentificado'] )
	{
		echo '<script>
	    alert("Debe iniciar sesión para acceder al sistema");
	    location.href="ingresar.php";
	    </script>';
	}
?>