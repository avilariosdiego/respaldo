<?php
	include_once('conexion/cnx.php');  //Agregando la Conexión a Base de Datos
	include_once('sesion.php');        //Agregando la Verificación de Sesión

    $idadmin = $_GET['id'];	  //Captando el valor del id

    $Q = " SELECT * FROM usuarios_admin";
    $RQ = mysqli_query($cnx, $Q) or die(mysqli_error($cnx));
    $countRQ = mysqli_num_rows($RQ);
    
    //Cantidad de Administradores a Eliminar
    if($countRQ > 3)
    {
        $queryEliminarA = "DELETE FROM usuarios_admin WHERE idadmin = '$idadmin'";
        $QEE = mysqli_query($cnx, $queryEliminarA) or die(mysqli_error($cnx));
    
        if ($QEE == true)
        {
            echo '<script> location.href="usuarios.php"; </script>';
        }
    }else{
        echo '<script> alert("No se puede eliminar el usuario Administrador!"); 
            location.href="usuarios.php"; </script>';
    }
?>