<?php
    //Validando que exista el boton de envío
    if ( isset($_POST['modificar']) ){
        //Incluyendo la conexión a la Base De Datos
        include_once('conexion/cnx.php');
        //Captando el valor de los campos en el formulario
        $nombre     = $_POST['nombre'];
        $apellido   = $_POST['apellido'];
        $cedula     = $_POST['cedula'];
        $contraseña = md5($_POST['contraseña']);
        $idcargo    = $_POST['cargo'];
        $idempresa  = $_POST['empresa'];

        //Captando el valor del id
        $idusuario = $_REQUEST['id'];

        //Validando que exista algún valor en los campos
        if (empty($nombre) || empty($apellido) || empty($cedula) || empty($contraseña) || empty($idcargo) || empty($idempresa) )
        {
            echo '<script> alert("Algunos campos se encuentran vacíos"); location.href="usuarios.php"; </script>';
        }else{
            // Actualizando datos en la tabla de Usuarios Administradores
            $queryActualizarA = "UPDATE usuarios SET nombre='$nombre', apellido='$apellido', cedula='$cedula', idcargo='$idcargo', idempresa='$idempresa', clave='$contraseña' WHERE idusuario='$idusuario'";
            $QA1 = mysqli_query($cnx, $queryActualizarA) or die(mysqli_error($cnx));

            // Mostrando mensaje verificando que se modificaron los datos
            if($QA1 == true){
                echo '<script> alert("Usuario empleado actualizado correctamente"); location.href="usuarios.php"; </script>';
            }
        }
    }
?>